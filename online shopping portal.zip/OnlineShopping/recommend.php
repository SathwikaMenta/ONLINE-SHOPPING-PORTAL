<?php 

$try = exec("./htdocs/Product/sample.py")

?>