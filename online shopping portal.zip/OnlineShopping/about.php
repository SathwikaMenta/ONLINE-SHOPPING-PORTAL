<?php
	include 'includes/header.php';
	include 'includes/left-bar.php';
?>
	<div class="col-md-6" style="background-color:#808080 ;min-height:570px;width :80%;">
		<br/>
		<br/><br/><br/><br/><br/>
		

        <div class="row centered-form" style="padding-top: 40px; padding-right: 80px;padding-bottom: 50px;padding-left: 300px;">
			<p>"Online shopping is a form of electronic commerce which allows consumers to directly buy goods or services from a seller over the Internet using a web browser or a mobile app."</p>

    	</div>
			
    	
    </div>

<?php include 'includes/footer.php'?>			