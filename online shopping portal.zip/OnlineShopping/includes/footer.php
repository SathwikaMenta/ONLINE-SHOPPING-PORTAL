		<div class="foot fix">
			<p class="centered">Welcome to Our Website !!!</p>
		</div>
	</div>
</body>
</html>
