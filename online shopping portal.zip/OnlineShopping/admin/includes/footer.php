		<div class="foot fix">
			<p class="centered">Welcome to Our Website!!! Happy shopping !!!</p>
		</div>
	</div>
</body>
</html>
