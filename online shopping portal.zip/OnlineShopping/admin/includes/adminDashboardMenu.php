<div style="background-color:black;right:0px;width:100px;height:820px;position:fixed;">
	<a href="allUsers.php">
	<button style="height:80px;">
		<div style="background: url('images/icons/alluser.png') no-repeat;background-size: 100%;width:100px;height:100px;position:relative;">
		</div>
	</button></a>
	<div style="background: black; background-size: 100%;margin-top:-10px;width:100px;height:20px;position:relative;">
		<p align="center">All Users</p>
	</div>
	<a href="addProduct.php">
	<button style="height:60px;">
		<div style="background: url('images/icons/add3.jpg') no-repeat;background-size: 100%;width:100px;height:60px;position:relative;">
		</div>
	</button></a>
	<div style="background-size: 100%;width:100px;height:20px;position:relative;">
		<p align="center">Add Product</p>
	</div>
	<a href="removeProduct.php">
	<button style="height:80px;">
		<div style="background: url('images/icons/del.png') no-repeat;background-size: 100%;width:100px;height:60px;position:relative;">
		</div>
	</button></a>
	<div style="background-size: 100%;width:100px;height:40px;position:relative;">
		<p align="center">Remove Product</p>
	</div>

	<a href="changePassword.php">
	<button style="height:60px;">
		<div style="background: url('images/icons/66.png') no-repeat;background-size: 100%;width:100px;height:60px;position:relative;">
		</div>
	</button></a>
	<div style="background-size: 100%;width:100px;height:40px;position:relative;">
		<p align="center">Change Password</p>
	</div>
</div>